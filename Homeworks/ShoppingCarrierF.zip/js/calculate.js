"use strict"


let displayprice = document.querySelector("#displayprice");
let price1 = 5;
let price2 = 10;
let price3 = 15;

let number1 = document.querySelector("#number1");
let number2 = document.querySelector("#number2");
let number3 = document.querySelector("#number3");


function add(num)
{
    if (num == 1)
    {
        console.log(num, 'add', number1);
        number1 = number1 + 1;
        console.log(number1);
        number1.textContent = number1;
        //报错在这一行
    }
}